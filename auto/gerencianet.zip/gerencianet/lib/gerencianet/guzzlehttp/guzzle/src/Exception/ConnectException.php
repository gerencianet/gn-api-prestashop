<?php
namespace GuzzleHttp\Exception;

class ConnectException extends RequestException {}
