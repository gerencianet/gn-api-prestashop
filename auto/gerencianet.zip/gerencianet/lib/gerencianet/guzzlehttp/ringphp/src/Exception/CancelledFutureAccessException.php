<?php
namespace GuzzleHttp\Ring\Exception;

class CancelledFutureAccessException extends RingException implements CancelledException {}
